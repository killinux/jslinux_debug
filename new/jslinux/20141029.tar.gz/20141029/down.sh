#!/bin/sh  
for strr in $(seq 999)  
do  
    stmp=$((1000000000+$strr));  
    echo "wget http://jslinux.org/hda$stmp.bin";  
done  
